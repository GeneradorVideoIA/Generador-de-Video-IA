# Generador De Video IA — prototipo Android 0.2.0

Este proyecto crea una primera app Android con Kotlin y Jetpack Compose.

## Qué contiene
- Pantalla principal en español.
- Campo para describir el video.
- Selectores de formato, voz y duración.
- Diseño oscuro adaptable a Android.
- Flujo de GitHub Actions para compilar el APK en la nube, sin PC local.

## Limitaciones importantes
Este prototipo NO genera videos todavía. El botón solo valida que se haya escrito una idea. Todavía faltan los servicios/modelos reales para generar imágenes o clips, voz, música, subtítulos, ensamblar el MP4 y guardarlo. El ZIP no incluye claves API ni servicios de pago.

No se puede garantizar generación ilimitada y gratuita con calidad comercial. El modo local reduce dependencia de servidores, pero en un teléfono de 6 GB de RAM se deben usar modelos ligeros y clips cortos; la generación avanzada suele requerir un servidor GPU y puede tener costes.

## Cómo obtener el APK usando solo el celular
1. Descarga el ZIP y descomprímelo con la app Mis archivos o una herramienta de archivos.
2. En el navegador del celular, entra a https://github.com y crea una cuenta o inicia sesión.
3. Crea un repositorio nuevo llamado `GeneradorDeVideoIA`.
4. En el repositorio, usa Add file > Upload files. Sube el contenido de esta carpeta (no el ZIP como un solo archivo): asegúrate de incluir la carpeta `.github/workflows`.
5. Confirma el commit en la rama `main`.
6. Abre la pestaña Actions del repositorio. Selecciona `Build Android APK` si hace falta y espera a que termine en verde.
7. Abre la ejecución completada y descarga el artefacto `Generador-De-Video-IA-debug`.
8. Descomprime ese artefacto y toca `app-debug.apk` para instalarlo. Si Android lo solicita, permite instalar aplicaciones desde ese navegador o gestor de archivos.

## Si GitHub no muestra Upload files para carpetas
Desde el navegador activa "Sitio para computadora" y vuelve a intentar. La carpeta `.github` puede ser oculta; comprueba que también se haya subido.

## Para la siguiente fase
Conectar un backend seguro para generación de escenas e imágenes, narración, música, subtítulos y exportación MP4. No incrustar claves secretas de proveedores dentro de la app.
