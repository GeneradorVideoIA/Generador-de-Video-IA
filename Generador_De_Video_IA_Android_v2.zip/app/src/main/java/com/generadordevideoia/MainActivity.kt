package com.generadordevideoia

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Subtitles
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Ink = Color(0xFF0B1020)
private val Panel = Color(0xFF171F35)
private val Purple = Color(0xFF8B5CF6)
private val Mint = Color(0xFF65E6B3)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                primary = Purple, background = Ink, surface = Panel,
                onPrimary = Color.White, onBackground = Color.White, onSurface = Color.White
            )) { VideoStudioScreen() }
        }
    }
}

@Composable
fun VideoStudioScreen() {
    var prompt by remember { mutableStateOf("") }
    var ratio by remember { mutableStateOf("Vertical 9:16") }
    var duration by remember { mutableStateOf("30 segundos") }
    var voice by remember { mutableStateOf("Español — voz femenina") }
    var status by remember { mutableStateOf("Listo para crear") }

    Surface(Modifier.fillMaxSize(), color = Ink) {
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 18.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(46.dp).background(
                    Brush.linearGradient(listOf(Purple, Color(0xFF4F46E5))),
                    RoundedCornerShape(15.dp)), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.Movie, null, tint = Color.White, modifier = Modifier.size(27.dp))
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("GENERADOR DE", fontSize = 11.sp, color = Mint, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                    Text("VIDEO IA", fontSize = 23.sp, fontWeight = FontWeight.Black, color = Color.White)
                }
                Text("BETA", color = Mint, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }

            Box(
                Modifier.fillMaxWidth().background(
                    Brush.linearGradient(listOf(Color(0xFF35216D), Color(0xFF182746))),
                    RoundedCornerShape(22.dp)).padding(18.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("De una idea a un video", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text("Escribe tu historia. Esta versión prepara la configuración para crear escenas, imágenes, voz y música.",
                        color = Color(0xFFD4D8E8), fontSize = 14.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FeatureChip("Texto a video")
                        FeatureChip("Editor IA")
                    }
                }
            }

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("¿QUÉ VIDEO QUIERES CREAR?", color = Mint, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.3.sp)
                OutlinedTextField(
                    value = prompt, onValueChange = { prompt = it },
                    modifier = Modifier.fillMaxWidth().heightIn(min = 145.dp),
                    placeholder = { Text("Ejemplo: Un documental cinematográfico sobre los misterios del océano, narrado en español...") },
                    shape = RoundedCornerShape(16.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Purple, unfocusedBorderColor = Color(0xFF3A4561),
                        focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                        focusedContainerColor = Panel, unfocusedContainerColor = Panel
                    )
                )
            }

            Text("CONFIGURACIÓN DEL VIDEO", color = Mint, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.3.sp)
            SettingCard(Icons.Default.Movie, "Formato", ratio, listOf("Vertical 9:16", "Horizontal 16:9", "Cuadrado 1:1")) { ratio = it }
            SettingCard(Icons.Default.RecordVoiceOver, "Narración", voice,
                listOf("Español — voz femenina", "Español — voz masculina", "Sin narración")) { voice = it }
            SettingCard(Icons.Default.Subtitles, "Duración inicial", duration,
                listOf("15 segundos", "30 segundos", "60 segundos", "3 minutos")) { duration = it }

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FeatureTile(Icons.Default.AutoAwesome, "Imágenes IA", Modifier.weight(1f))
                FeatureTile(Icons.Default.MusicNote, "Música", Modifier.weight(1f))
                FeatureTile(Icons.Default.Subtitles, "Subtítulos", Modifier.weight(1f))
            }

            Button(
                onClick = {
                    status = if (prompt.isBlank()) "Escribe una idea para continuar"
                    else "Tu idea está lista. El motor de generación IA aún debe conectarse."
                },
                modifier = Modifier.fillMaxWidth().height(56.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Purple)
            ) {
                Icon(Icons.Default.AutoAwesome, null)
                Spacer(Modifier.width(8.dp))
                Text("PREPARAR MI VIDEO", fontWeight = FontWeight.Bold)
            }
            Text(status, color = Mint, fontSize = 12.sp)
            Text("Prototipo inicial: todavía no genera ni exporta videos. La conexión de los motores IA será una fase posterior.",
                color = Color(0xFF8994AE), fontSize = 11.sp)
            Spacer(Modifier.height(12.dp))
        }
    }
}

@Composable
fun FeatureChip(label: String) {
    Surface(color = Color(0x553B82F6), shape = RoundedCornerShape(50)) {
        Text(label, Modifier.padding(horizontal = 10.dp, vertical = 6.dp), color = Color.White, fontSize = 11.sp)
    }
}

@Composable
fun SettingCard(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, selected: String,
                options: List<String>, onSelect: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    Surface(color = Panel, shape = RoundedCornerShape(15.dp), modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(13.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, null, tint = Purple)
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(title, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                    Text(selected, color = Color(0xFFABB5CC), fontSize = 12.sp)
                }
                TextButton(onClick = { expanded = true }) { Text("CAMBIAR") }
                DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                    options.forEach { option ->
                        DropdownMenuItem(text = { Text(option) }, onClick = { onSelect(option); expanded = false })
                    }
                }
            }
        }
    }
}

@Composable
fun FeatureTile(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, modifier: Modifier = Modifier) {
    Surface(modifier, color = Panel, shape = RoundedCornerShape(13.dp)) {
        Column(Modifier.padding(vertical = 14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(icon, null, tint = Mint)
            Spacer(Modifier.height(5.dp))
            Text(label, fontSize = 11.sp, color = Color(0xFFD8DDF0))
        }
    }
}
